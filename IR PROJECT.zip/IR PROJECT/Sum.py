class sumClass:
    def doubleOfNumbers(num):
        return num*2


